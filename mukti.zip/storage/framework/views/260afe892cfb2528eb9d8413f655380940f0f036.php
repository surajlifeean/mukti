<?php $__env->startSection('content'); ?>

	
 <div class="row">

   	<div class="col-md-6 col-md-offset-3">

    <?php echo Form::model($identitydetail,['route'=>['editdetails.update',$identitydetail->id],'method'=>'PUT','files'=>true]); ?>



  	<?php echo e(Form::label('name', 'Name:')); ?>

    
  	<?php echo e(Form::text('name', null, ["class"=>'form-control input-lg'])); ?>




    <?php echo e(Form::label('maritalstatus','Marital Status:')); ?>


    <select class="form-control" name="maritalstatus">
    
    	<option selected=<?php echo e($identitydetail->marital_status); ?>><?php echo e(ucwords($identitydetail->marital_status)); ?></option>
     
     
          <option value="single">Single</option>
          
          <option value="married">Married</option>

          <option value="widow">Widow</option>

          <option value="divorced">Divorced</option>
		    
    </select>


 <?php echo e(Form::label('pan_no','Pan Card Number:')); ?>


    <?php echo e(Form::text('pan_no',null,array('class'=>'form-control','required'=>''))); ?>



    <?php echo e(Form::label('aadhar_no','Aadhar Card Number:')); ?>


    <?php echo e(Form::text('aadhar_no',null,array('class'=>'form-control','required'=>''))); ?>



     <?php echo e(Form::label('address','Address:')); ?>


	<input type="text" class='form-control' name='address' value=<?php echo e($addressdetail->address); ?>>

    <?php echo e(Form::label('city','City:')); ?>


	<input type="text" class='form-control' name='city' value=<?php echo e($addressdetail->city); ?>>

    <?php echo e(Form::label('pin','Pin:')); ?>


    <input type="text" class='form-control' name='pin' value=<?php echo e($addressdetail->pin); ?>>

    <?php echo e(Form::label('phone_no','Phone No.:')); ?>

	
    <input type="text" class='form-control' name='phone_no' value=<?php echo e($addressdetail->phone_no); ?>>


    <?php echo e(Form::label('income','Gross Annual Income:')); ?>  

    <select class="form-control" name="income">
    	<option selected=<?php echo e($otherdetail->salary); ?>><?php echo e($otherdetail->salary); ?></option>
     
          <option value="less than 1 lakhs">Below 1 lakhs</option>
          
          <option value="1-5 lakhs">1 to 5 lakhs</option>

          <option value="5-10 lakhs">5 to 10 lakhs</option>

          <option  value="10-25 lakhs">10 to 25 lakhs</option>

          <option value="over 25 lakhs">more than 25 lakhs</option>  

		    
    </select>

	<?php echo e(Form::label('occupation','Occupation:')); ?> 


    <select class="form-control occupation" name="occupation" selected=<?php echo e($otherdetail->occupation); ?>>
    		
    	<option selected=<?php echo e($otherdetail->occupation); ?>><?php echo e(ucwords($otherdetail->occupation)); ?></option>
     
          <option value="private sector">Private Sector</option>
          
          <option value="Public Sector">Public Sector</option>

          <option value="Agriculture">Agriculture</option>


          <option value="Government Service">Government Service</option>
          
          <option value="Retired">Retired</option>

          <option value="Housewife">Housewife</option>


          <option value="Business">Business</option>

          
          <option value="Professional">Professional</option>
          
          <option value="Student">Student</option>

          <option value="Housewife">Housewife</option>


            <option  value="others">Others</option>       
		    
    </select>

    <?php echo e(Form::label('featured_image','Upload Image')); ?>


    <?php echo e(Form::file('featured_image')); ?>


    <?php echo e(Form::label('featured_image2','Upload Aadhar Image')); ?>


    <?php echo e(Form::file('featured_image2')); ?>


    <?php echo e(Form::label('featured_image3','Upload PAN Image/Voters ID Image')); ?>


    <?php echo e(Form::file('featured_image3')); ?>




	
    
   
            <?php echo e(Form::submit('Save Changes',array('class'=>"btn btn-success btn-block form-spacing-top",'style'=>'margin-top:20px'))); ?>

                  

	  </div>
	
  <?php echo Form::close(); ?>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>