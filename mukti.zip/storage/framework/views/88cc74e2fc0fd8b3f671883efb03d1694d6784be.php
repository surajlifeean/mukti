<?php $__env->startSection('content'); ?>
<div class="row">
<div class="col-md-8 col-md-offset-2">
   <h1 class="alert alert-success" role="alert">Deposit Premium</h1>
   <?php echo e(Form::open(['route'=>['premiums.store'],'method'=>'POST'])); ?>

   <h3><?php echo e(Form::label('name',$matchinglist->name)); ?></h3><br>

	<?php echo e(Form::label('principal','Alloted Amount:')); ?>   
   <input type="text" name="principal" class="form-control" value=<?php echo e($matchinglist->principal); ?> readonly>

   <?php echo e(Form::label('ewi','EWI:')); ?>   
   <input type="text" name="ewi" class="form-control" value=<?php echo e($matchinglist->ewi); ?>>
   

   <?php echo e(Form::label('fine','Fine:')); ?>   
   <input type="text" name="fine" class="form-control" value=<?php echo e($fine); ?> readonly>
   
   Installment No:<?php echo e(Form::label('fine',$preno)); ?>/<b><?php echo e($totinst); ?></b>
   
   <input type="hidden" name="premium" class="form-control" value=<?php echo e($matchinglist->nextpremiumdate); ?>>
   
    <input type="hidden" name='customer_id' value=<?php echo e($matchinglist->id); ?>></input>


    <input type="hidden" name='preno' value=<?php echo e($preno); ?>></input>

<?php echo e(Form::submit('Pay EWI',array('class'=>'btn btn-success btn-lg btn-block','style'=>'margin-top:20px'))); ?>



   <?php echo e(Form::close()); ?>

</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
	<?php echo Html::script('js/parsley.js'); ?>

     <?php echo Html::script('js/select2.js'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>