<?php $__env->startSection('content'); ?>
<div class="row">
<div class="col-md-8 col-md-offset-2">
  

   <h1 class="alert alert-success" role="alert">Rate Chart</h1>
</div>
</div>

<div class="col-md-8 col-md-offset-2">
  
  
<table class="table table-striped">

<thead>
	<tr>
		<th>Scheme</th>

		<th>Principal</th>
		
		<th>Interest Rate</th>
		
		<th>No Of Installments</th>
		
		<th>EWI</th>
		
		<th>Processing Fees</th>
		
		<th>Pads Quantity</th>		
	</tr>
</thead>	
<tbody>

   		   		 
  <?php $__currentLoopData = $rates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <tr>
     	<td>M
    <?php echo e($rate->scheme); ?>

    </td><td>
   	<?php echo e($rate->principal); ?>

   	</td><td>
   	<?php echo e($rate->interestrate); ?>

   	</td><td>
   	<?php echo e($rate->noofinstallments); ?>

   	</td><td>
   	<?php echo e($rate->ewi); ?>

   	</td><td>
   	<?php echo e($rate->processingfees); ?>

   	</td><td>
   	<?php echo e($rate->muktipadsqty); ?>


             
    </td>
  </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      
</tbody>
       </table>
       </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>