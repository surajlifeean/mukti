<?php $__env->startSection('content'); ?>
<?php 
            $totalewi=0;
            $totalpaid=0;
          ?>

  <?php $__currentLoopData = $paydetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      
         <?php 
            $totalewi=$totalewi+$pay->ewi;
            $totalpaid=$totalpaid+$pay->amount_paid;
          ?>
      

  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div class="row">
 <div class="col-md-8 col-md-offset-2">
   <h1 class="alert alert-success" role="alert">Premium Status</h1><h3><b>Due Amount:Rs<?php echo e($totalewi-$totalpaid); ?> 
              <?php if($custdetails->loan_alloted==1): ?>
              <a class="btn" href="<?php echo e(route('paymentreport.show',$custdetails->id)); ?>" role="button"><span class="glyphicon glyphicon-stats"></span></a>
              <?php endif; ?>
</b></h3>
   <table class="table table-striped">
   		<tbody>
   		<tr><td>
   Customer Name: <?php echo e($custdetails->name); ?>


   		</td></tr> 
   	<tr><td>
   	Address:<?php echo e($custdetails->address); ?>,
   	<?php echo e($custdetails->city); ?>,
   	<?php echo e($custdetails->pin); ?>,
   	<?php echo e($custdetails->state); ?>,
   	</td></tr>
    <tr><td>
   	Contact No:<?php echo e($custdetails->phone_no); ?>

   	</td></tr>

	

   	<tr><td>
   	Loan Amount:<?php echo e($custdetails->principal); ?>

   	</td></tr>

   	<tr><td>
    <b>	Fine for <?php echo e($finedays); ?> days = Rs<?php echo e($fine); ?></b>
   	</td></tr>

   	<tr><td>
   	Installment:<?php echo e($premium->ewi); ?>

   	</td></tr>

   	<tr><td>
   	Loan Allotment Date:<?php echo e(date('jS M, Y', strtotime($custdetails->created_at))); ?>

   	</td></tr>
   <tr><td>
   	Latest Due Premium Date:<?php echo e(date('jS M, Y', strtotime($custdetails->nextpremiumdate))); ?><br>
      </td></tr>
   <tr><td>
      Today is:<?php echo e(date("jS M, Y")); ?>

   	</td></tr>
   		</tbody>
   	</table>
   	<a href="<?php echo e(route('premiums.index')); ?>" class="btn btn-primary">Back</a>
      <?php if($hide): ?>
        <p></p>
      <?php else: ?>
      <?php if($custdetails->status=="active"): ?>
         <?php if($custdetails->group_id): ?>            
            	<a href="<?php echo e(route('shgprem.show',$custdetails->group_id)); ?>" class="btn btn-primary">Pay Premium</a>
         <?php else: ?>
                <a href="<?php echo e(route('premiums.edit',$custdetails->id)); ?>" class="btn btn-primary">Pay Premium</a>   
         <?php endif; ?>
      <?php endif; ?> 
      <?php endif; ?>

 
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>