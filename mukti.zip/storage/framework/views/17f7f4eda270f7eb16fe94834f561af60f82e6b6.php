<!--<?php echo e(dump($groupmembers)); ?>-->





<?php $__env->startSection('content'); ?>


<div class="row">
 <div class="col-md-8 col-md-offset-2">
    <h1 class="alert alert-success" role="alert">Nominate Mukti Maa</h1>

<?php echo Form::open(['route' => 'muktimaa.store','data-parsley-validate'=>'']); ?>


	<?php $__currentLoopData = $groupmembers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	
	  <input class=".radio-primary" type="radio" name="maa" value=<?php echo e($member->id); ?>> <?php echo e($member->name); ?>  <br>
	
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    <?php echo e(Form::submit('Done',array('class'=>'btn btn-success btn-md','style'=>'margin-top:20px'))); ?>


    
<?php echo Form::close(); ?>


	 </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>