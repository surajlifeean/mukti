<?php $__env->startSection('content'); ?>

<div class="col-md-8 col-md-offset-2">
   <h1 class="alert alert-success" role="alert">Due Premium <span class="badge"><?php echo e($count); ?></span>
            </h1>
</div>

<table class="table table-striped">
   		<tbody>

   		   		 
  <?php $__currentLoopData = $matchinglist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <tr><td>
    <div class="row">
       <div class="col-md-8 col-md-offset-2" >
         <div class="list">
           <h3><?php echo e(ucwords($list->name)); ?>  </h3>
             <p>
    Resident of:<?php echo e($list->address); ?>,
   	<?php echo e($list->city); ?>,
   	<?php echo e($list->pin); ?>.<br>
   	Contact No:<?php echo e($list->phone_no); ?>

   	Occupation:<?php echo e($list->occupation); ?><br>
    Loan Alloted on:<?php echo e(date('jS M, Y', strtotime($list->created_at))); ?><br>
    Date of Payment:<?php echo e(date('jS M, Y', strtotime($list->nextpremiumdate))); ?>


    <?php if($list->group_id): ?>
     <b>SHG:<?php echo e($list->group_id); ?></b>
    <?php endif; ?>
             </p>

              <p><a class="btn btn-primary" href="<?php echo e(route('premiums.show',$list->id)); ?>" role="button">Deposit Premium</a></p>
              <hr>
         </div>
       </div>

    </div>
       		</td></tr>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      
       </tbody>
  </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>