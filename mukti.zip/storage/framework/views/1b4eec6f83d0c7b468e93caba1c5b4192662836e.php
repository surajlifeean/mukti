<!--<?php echo e(dump($details)); ?>-->



<?php $__env->startSection('content'); ?>


<div class="col-md-8 col-md-offset-2">
   <h1 class="alert alert-success" role="alert">View Groups</h1>
</div>

<table class="table table">
   		<tbody>

   		<?php 
   			$oldval=0;
   		 ?>

   		   		 
  <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr><td>   
    <div class="row">
       <div class="col-md-8 col-md-offset-2" >

    		
       		 <?php if($loop->first): ?>
                	<?php 
                   		$oldval=$detail->group_id

                   	 ?>
                <h3>Group ID:<?php echo e($detail->group_id); ?></h3>
                <?php else: ?>
                  <?php if($oldval != $detail->group_id): ?>
                   <p><a class="btn btn-primary" href="<?php echo e(route('shgs.show',$oldval)); ?>" role="button">Group  Status</a></p>
                                      <hr>

                    <h3>Group ID:<?php echo e($detail->group_id); ?></h3>


              
                  	<?php 
                   		$oldval=$detail->group_id
                   	 ?>
                  <?php endif; ?>
                <?php endif; ?>


       			        <?php echo e(ucwords($detail->name)); ?> 
             
                    Resident of:<?php echo e($detail->address); ?>,
   	                <?php echo e($detail->city); ?>,
   	                    <br>
   	                Contact No:<?php echo e($detail->phone_no); ?>

                    <br>
  <?php if($detail->status=="active"): ?>
    <p class="status" style="color:#00ff00">Status:<?php echo e($detail->status); ?>

  <?php else: ?>
      <p class="status" style="color:#ff0000">Status:<?php echo e($detail->status); ?>


  <?php endif; ?>

                               <?php if($loop->last): ?>
                	<p><a class="btn btn-primary" href="<?php echo e(route('shgs.show',$oldval)); ?>" role="button">Group Status</a></p>
              
                <?php endif; ?>

   
             
              
       </div>
	</div>

           	</td></tr> 
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      
       </tbody>
  </table>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>