<?php $__env->startSection('content'); ?>

 
<div class="row">
  <div class="col-md-3 col-md-offset-2">
    <?php echo e(Form::open(['route'=>['searchcustomers.store'],'method'=>'POST'])); ?>


     <?php echo e(Form::label('searchby','Search By')); ?>


    <select class="form-control searchby" name="searchby">
    
     
          <option value="name">Name</option>
          
          <option value="city">Place</option>


          <option value="city">Customer ID</option>
        
    </select>
  </div>

  <div class="col-md-3">  
<b>
      <p>Search Data</p>  </b>
      <?php echo e(Form::text('name',null,['class'=>'form-control'])); ?>


  </div>

  <div class="col-md-3">  
      <?php echo e(Form::submit('search',['class'=>'btn btn-primary','style'=>'margin-top:25px'])); ?>


    <?php echo e(Form::close()); ?>

    </div>

 </div>



<table class="table table-striped">
   		   		   		 
  <?php $__currentLoopData = $matchinglist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <tr><td>
    <div class="row">
       <div class="col-md-8 col-md-offset-2" >
         <div class="list">
           <h3><?php echo e(ucwords($list->name)); ?>  </h3>
             <p>
    Resident of:<?php echo e($list->address); ?>,
   	<?php echo e($list->city); ?>,
   	<?php echo e($list->pin); ?>,
   	<?php echo e($list->state); ?>,
   	<?php echo e($list->country); ?>.<br>
   	Contact No:<?php echo e($list->phone_no); ?><br>
	Joined At:<?php echo e(date('jS M, Y', strtotime($list->created_at))); ?>

   
              <a class="btn" href="<?php echo e(route('customers.show',$list->id)); ?>" role="button"><span class="glyphicon glyphicon-list-alt"></span></a>
              
              
              <a class="btn" href="<?php echo e(route('editdetails.edit',$list->id)); ?>" role="button"><span class=" glyphicon glyphicon-pencil"></span></a>


              <?php if($list->loan_alloted==1): ?>
              <a class="btn" href="<?php echo e(route('paymentreport.show',$list->id)); ?>" role="button"><span class="glyphicon glyphicon-stats"></span></a>
              <?php endif; ?>
              </p>
              <hr>
         </div>
       </div>

    </div>
       		</td></tr>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

       
  </table>


<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>