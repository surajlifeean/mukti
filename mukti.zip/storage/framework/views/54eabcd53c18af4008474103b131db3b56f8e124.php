<?php $__env->startSection('content'); ?>



<table class="table table-striped">
   		   		   		 
  <?php $__currentLoopData = $matchinglist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <tr><td>
    <div class="row">
       <div class="col-md-8 col-md-offset-2" >
         <div class="list">
           <h3><?php echo e(ucwords($list->name)); ?>  </h3>
             <p>
    Resident of:<?php echo e($list->address); ?>,
   	<?php echo e($list->city); ?>,
   	<?php echo e($list->pin); ?>,
   	<?php echo e($list->state); ?>,
   	<?php echo e($list->country); ?>.<br>
   	Contact No:<?php echo e($list->phone_no); ?>

  <?php if($list->status=="active"): ?>
    <p class="status" style="color:#00ff00">Status:<?php echo e($list->status); ?>

  <?php else: ?>
      <p class="status" style="color:#ff0000">Status:<?php echo e($list->status); ?>


  <?php endif; ?>

             </p>
              <p>
              <a class="btn" href="<?php echo e(route('customers.show',$list->id)); ?>" role="button"><span class="glyphicon glyphicon-list-alt"></span></a>
              
              <?php if($list->status=="active"): ?>
              <a class="btn" href="<?php echo e(route('unregcust.show',$list->id)); ?>" role="button"><span class="glyphicon glyphicon-trash"></span></a>
              <?php endif; ?>
              
              <a class="btn" href="<?php echo e(route('editdetails.edit',$list->id)); ?>" role="button"><span class=" glyphicon glyphicon-pencil"></span></a>
              </p>
              <hr>
         </div>
       </div>

    </div>
       		</td></tr>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      
  </table>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>