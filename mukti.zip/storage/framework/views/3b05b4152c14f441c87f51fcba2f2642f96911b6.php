<?php $__env->startSection('content'); ?>

<div class="row">
	<div class="col-md-6 col-md-offset-3">

			<h3>Are You Sure You Want to Un-Register  <?php echo e(ucwords($matchinglist->name)); ?> ?</h3>

			<?php echo Form::open(['route' => ['unregcust.destroy',$matchinglist->id],'method'=>'delete']); ?>


             <?php echo e(Form::submit('Yes!',array('class'=>'btn btn-danger'))); ?>

    	<a class="btn btn-info " href="<?php echo e(route('searchcustomers.index')); ?>" role="button">No.</a>


    
<?php echo Form::close(); ?>


  	</div>
 </div>  

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>