<!--<?php echo e(dump($gid)); ?>-->




<?php $__env->startSection('content'); ?>

<?php echo Form::open(['route' =>['shgs.update',$gid],'data-parsley-validate'=>'','method'=>'PUT']); ?>


<div class="row">
<div class="col-md-6 col-md-offset-3">
<!--
<?php echo e(Form::label('weightage','Loan Weightage:')); ?>

   <select class="weightage form-control" name="weightage">
    
          <option value="selects">select</option>
          

          <option value="equal">Equal</option>

          
          <option value="variable">Variable </option>

		    
    </select>
<br>
-->


    <select class="principal form-control" name="amt">

          <option value="0000">Select Amount</option>
     
     
          <option value="1000">Rs 1000</option>
          
          <option value="2000">Rs 2000</option>

          <option value="3000">Rs 3000</option>


          <option value="4000">Rs 4000</option>
          
          <option value="5000">Rs 5000</option>

          <option value="6000">Rs 6000</option>


          <option value="7000">Rs 7000</option>

          
          <option value="8000">Rs 8000</option>
          
          <option value="9000">Rs 9000</option>

          <option value="10000">Rs 10000</option>

          </select>


   <?php echo e(Form::label('processfee','Processing Fees:')); ?>

   <input type="text" name="processfee" class="form-control processfee">
         
<div class="form-spacing-top">
  <table class="table table-bordered"> 
    <thead>
          <tr>
              <th> Member</th>
              
              <th> Pads Qty</th>

          </tr>
    </thead>
    <tbody>

    <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
     <tr>
        <td>
            <input type="hidden" name="id[]" value=<?php echo e($detail->id); ?>><?php echo e($detail->name); ?>

        </td>

        <td>
              <input type="text" class="form-control" name="pdsqty[]" id="i<?php echo e($detail->id); ?>">
          </td>


      </tr>
		  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



      </tbody>
    </table>
  
</div>

     <?php echo e(Form::submit('Allot',array('class'=>'btn btn-success btn-lg btn-block','style'=>'margin-top:20px'))); ?>




<?php echo Form::close(); ?>

    </div>
 </div>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
	<?php echo Html::script('js/parsley.js'); ?>

     <?php echo Html::script('js/select2.js'); ?>


<script type="text/javascript">


  $(function(){

$('.principal').change(function(){


    if($('.principal').val()<3000)
      $('.processfee').attr('value',20);
    
    else if($('.principal').val()<6000)
      $('.processfee').attr('value',50);
    else
      $('.processfee').attr('value',100);
});

  });

</script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>