<?php $__env->startSection('content'); ?>
  
<div class="row">
	<div class="col-md-6 col-md-offset-3">
  	<?php echo e(Form::open(['route'=>['searchcustomers.store'],'method'=>'POST'])); ?>


 		 <?php echo e(Form::label('searchby','Search By')); ?>


 		<select class="form-control searchby" name="searchby">
    
     
          <option value="name">Name</option>
          
          <option value="city">Place</option>
		    
    </select>
<br>
<b>
  		<p>Enter the name or a few letter of name</p>  </b>
  		<?php echo e(Form::text('name',null,['class'=>'form-control'])); ?>

  		<?php echo e(Form::submit('search',['class'=>'btn btn-primary'])); ?>


  	<?php echo e(Form::close()); ?>

  	</div>
 </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

<script type="text/javascript">


$('.searchby').change(function(){


    if($('.searchby').val()=="place")
    	$('p').html("Enter the name of the place or few letters");


});


</script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>