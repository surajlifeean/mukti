<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-body">
                <table class="table">
                <b>
                    
                    <tr>
                        <td class="active" align="center"><a href="<?php echo e(route('shgs.create')); ?>">Create SHG</a></td>
                    </tr>
<!--                    <tr>
                        <td class="success" align="center"><a href="<?php echo e(route('searchcustomers.index')); ?>">Edit SHG</a></td>
                    </tr>
-->
                    <tr>    
                        <td class="danger" align="center"><a href="<?php echo e(route('indorshg.view')); ?>">View SHG</a></td>
                        
                    </tr>

                    <tr>    
                        <td class="success" align="center"><a href="<?php echo e(route('shgprem.index')); ?>"> Premium</a></td>
                        
                    </tr>
                    
                  

                </b>
                </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>