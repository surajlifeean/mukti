<?php $__env->startSection('stylesheet'); ?>
	
		<?php echo Html::style('css/parsley.css'); ?>


        <?php echo Html::style('css/select2.css'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<div class="row">
	<div class="col-md-6 col-md-offset-3">

<?php echo e(Form::open(array('route'=>'documents.store','data-parsley-validate'=>'','files'=>true))); ?>

<?php echo e(Form::label('featured_image','Upload Image')); ?>


<?php echo e(Form::file('featured_image')); ?>


    <?php echo e(Form::label('id','ID:')); ?>


    <?php echo e(Form::text('id',null,array('class'=>'form-control','required'=>''))); ?>


<?php echo e(Form::submit('submit',array('class'=>'btn btn-success btn-lg btn-block','style'=>'margin-top:20px'))); ?>


<?php echo e(Form::close()); ?>

</div>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
	<?php echo Html::script('js/parsley.js'); ?>

     <?php echo Html::script('js/select2.js'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>