<?php $__env->startSection('content'); ?>

<div class="row">
	<div class="col-md-6 col-md-offset-3">

	<h3>Customer is no more a member of <b>Mukti.</b></h3>
	<a class="btn btn-info " href="<?php echo e(route('searchcustomers.index')); ?>" role="button">Get Back</a>


    
  	</div>
 </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>