<!--<?php echo e(dump($matchinglist)); ?>-->






<?php $__env->startSection('content'); ?>

<div class="col-md-8 col-md-offset-2">
   <h1 class="alert alert-success" role="alert">Due Premium <span class="badge"><?php echo e($count); ?></span>
            </h1>
</div>

<table class="table table-striped">
   		<tbody>

  <?php echo e(Form::open(['route'=>['premiums.store'],'method'=>'POST'])); ?>

      		 
  <?php $__currentLoopData = $matchinglist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <tr><td>
    <div class="row">
       <div class="col-md-8 col-md-offset-2" >
         <div class="list">
          <a href="<?php echo e(route('shgprem.show',$list->group_id)); ?>"><b>SHG:<?php echo e($list->group_id); ?></b></a><br>
            <?php $__currentLoopData = $names; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($name->group_id ==$list->group_id): ?>
               
               <span class="label label-default">
           <?php echo e($name->name); ?></span>
   
              <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       		
           </div>
         </div>
        </div>
    </td></tr>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      
       </tbody>
  </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>