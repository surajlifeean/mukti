<!--<?php echo e(dump($matchinglist)); ?>-->

<?php $__env->startSection('content'); ?>
<div class="row">
<div class="col-md-8 col-md-offset-2">
   <h1 class="alert alert-success" role="alert">Deposit Group Premium</h1>
         <?php echo Form::open(['route' => 'shgprem.store','data-parsley-validate'=>'']); ?>


   <table class="table table-striped" style="font-size:10px;">
      <thead>
        <th>
            Pay Date
        </th>
        <th>
            Name
        </th>
        <th>
            Payment
        </th>
        <th>
            Fine
        </th>
        <th>
            Amount Paid
        </th>
      </thead>


  <?php $__currentLoopData = $matchinglist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <tbody>
       <?php if($loop->first): ?>
   
              <?php echo e(Form::label('principal','Alloted Amount To Each Member:')); ?>   
               <input type="text" name="principal" class="form-control" value=<?php echo e($list->principal); ?> readonly>

               <?php echo e(Form::label('ewi','EWI To Be Paid By Each:')); ?>   
               <input type="text" name="ewi" class="form-control" value=<?php echo e($list->ewi); ?> readonly>



          <?php endif; ?>

<?php if($list->status=="active"): ?>
         <?php if($list->nextpremiumdate<$currentdate): ?>
   
       
      <tr>
                  <td>

                              <input type="hidden" name='gid' value=<?php echo e($groupid); ?>></input>


                                <input type="hidden" name="date[]" class="form-control" value=<?php echo e(strtotime($list->nextpremiumdate)); ?>>

                                  <?php echo e(date('jS M, Y', strtotime($list->nextpremiumdate))); ?>

                                  </td>

                                  <td>
                                  <?php echo e($list->name); ?>

                                  </td>
                                  <td>
                                      <?php if($currentdate>=$list->nextpremiumdate): ?>
                                            
                                             <input type="checkbox" class="checkbox-primary" name="pay[]" value="<?php echo e($list->id); ?>"><br>
                                      <?php else: ?>
                                            
                                             <input type="checkbox" class="checkbox-primary" name="pay[]" value="<?php echo e($list->id); ?>" checked><br>
                                      
                                       <?php endif; ?>
                   </td>
                
                <td>
                 
                
                <?php if(date('Y-m-d', strtotime($currentdate))>date('Y-m-d', strtotime($list->nextpremiumdate))): ?>

                <?php if($list->principal<=5000): ?>
                            <?php 

                               $then = new DateTime(date('Y-m-d', strtotime($list->nextpremiumdate)));
                               $now = new DateTime(date('Y-m-d', strtotime($currentdate)));
        
                              $fdays=(date_diff($then,$now)->format("%d days") -1)*10;
                   
                             ?>
                            <input type="text" name="fine[]" class="form-control" value=<?php echo e($fdays); ?> size="2" readonly>

                            <?php else: ?>
                            <?php  
                               $then = new DateTime(date('Y-m-d', strtotime($list->nextpremiumdate)));
                               $now = new DateTime(date('Y-m-d', strtotime($currentdate)));
        
                              $fdays=(date_diff($then,$now)->format("%d days")-1)*20;
                             ?>

                            <input type="text" name="fine[]" class="form-control" value=<?php echo e($fdays); ?> size="2" readonly>

                  <?php endif; ?>

                  <?php else: ?>
                     <input type="text" name="fine[]" class="form-control" value=0 size="2" readonly>


                  <?php endif; ?>
                </td>

                <td>
                        <input type="text" name="amount_paid[]" class="form-control">

                </td>
      </tr>
  <?php endif; ?>   
<?php endif; ?>

  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <tr><td>
<?php echo e(Form::submit('Pay EWI',array('class'=>'btn btn-success btn-lg','style'=>'margin-top:20px'))); ?>

</td></tr>

</tbody>

   <?php echo e(Form::close()); ?>

</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
	<?php echo Html::script('js/parsley.js'); ?>

     <?php echo Html::script('js/select2.js'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>