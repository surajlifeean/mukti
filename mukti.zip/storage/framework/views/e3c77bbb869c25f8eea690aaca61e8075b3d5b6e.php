<?php $__env->startSection('content'); ?>

<div class="row">
	<div class="col-md-6 col-md-offset-3">
<h1>INSTALLMENT PAID</h1>

<?php if($clear): ?>
<div class="alert alert-success" role="alert"><h2>Your Loan Has Been Cleared</h2></div>
	</div>
<?php else: ?>
<div class="alert alert-success" role="alert"><h2>Next Premium Date:<?php echo e(date('d/m/y',strtotime($date))); ?></h2></div>
	
<?php endif; ?>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>