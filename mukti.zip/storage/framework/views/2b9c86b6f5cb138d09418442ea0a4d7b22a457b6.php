<?php $__env->startSection('content'); ?>

<?php echo Form::open(['route' =>['customers.update','0'],'data-parsley-validate'=>'','method'=>'PUT']); ?>


<div class="row">
<div class="col-md-6 col-md-offset-3">
<?php echo e(Form::label('individualorshg','Individual/SHG:')); ?>

    <select class="individualorshg form-control" name="indorshg">
    
     
          <option value="individual">Individual</option>
          
          <option value="shg"> SHG </option>

		    
    </select>
<div class="gs">
<?php echo e(Form::label('groupsize','Group Size:')); ?>


        <select class="group_size form-control" name="group_size">
    
     
          <option value="1">Select</option>
          
          <option value="4"> 4 </option>

          <option value="5"> 5 </option>

          <option value="6"> 6 </option>

          <option value="7"> 7 </option>
		    
    </select>
    </div>


     <?php echo e(Form::submit('Next',array('class'=>'btn btn-success btn-lg btn-block','style'=>'margin-top:20px'))); ?>




<?php echo Form::close(); ?>

    </div>
 </div>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
	<?php echo Html::script('js/parsley.js'); ?>

     <?php echo Html::script('js/select2.js'); ?>


<script type="text/javascript">


  $(function(){
  		$('.gs').hide();

$('.individualorshg').change(function(){

  		if($('.individualorshg').val()=="shg")
  				$('.gs').show();
  		else
  				$('.gs').hide();
  		});

  });

</script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>