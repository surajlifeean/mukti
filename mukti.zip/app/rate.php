<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class rate extends Model
{
    //
}
