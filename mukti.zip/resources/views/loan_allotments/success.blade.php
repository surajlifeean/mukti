@extends('layouts.app')


@section('content')
  
<div class="row">
	<div class="col-md-6 col-md-offset-3">
	<h1>Congrats Your Loan Has Been Alotted</h1>
	 <a  class="btn btn-primary" href="{{URL('home')}}">Home Page</a>
  	</div>
 </div>

@endsection