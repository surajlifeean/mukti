
@extends('layouts.app')


@section('content')


<div class="row">
 <div class="col-md-8 col-md-offset-2">
   <h1 class="alert alert-success" role="alert"> Group Registration is Done</h1>
   <h3>Group Id:{{$gid}}</h3>
  </div>
</div>
@endsection