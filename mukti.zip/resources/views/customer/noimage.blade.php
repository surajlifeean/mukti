@extends('layouts.app')

@section('stylesheet')
	

@endsection

@section('content')

 <img src="{{asset('images/no_image.jpg')}}">

@endsection