
@extends('layouts.app')


@section('content')

<div class="row">
	<div class="col-md-6 col-md-offset-3">

	<h3>Customer is no more a member of <b>Mukti.</b></h3>
	<a class="btn btn-info " href="{{route('searchcustomers.index')}}" role="button">Get Back</a>


    
  	</div>
 </div>
@endsection