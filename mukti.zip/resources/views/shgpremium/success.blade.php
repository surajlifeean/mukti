


@extends('layouts.app')


@section('content')


<div class="row">
	<div class="col-md-6 col-md-offset-3">
			<h1>INSTALLMENT PAID</h1>
	</div>
</div>

@endsection